Plugin Name: Daumbook
Plugin URI: http://www.bsidesoft.com/?p=450
Description: Daumbook 플러그인은 isbn으로 "다음검색API"를 이용해 워드프레스에서 책검색 결과를 포스트나 페이지에 쉽게 추가할 수 있도록 도와줍니다. This plugin uses Daum API and helps users easy to use in WordPress.
Version: 1.0
Author: bsidesoft
Author URI: http://www.bsidesoft.com


=== Plugin Name ===
Contributors: Bsidesoft
Donate link: http://www.bsidesoft.com/
Tags: shorttag, filter, book seach
Requires at least: 2.0.2
Tested up to: 4.0
Stable tag: 4.0
License: gpl2.0
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Daumbook 플러그인은 isbn으로 "다음검색API"를 이용해 워드프레스에서 책검색 결과를 포스트나 페이지에 쉽게 추가할 수 있도록 도와줍니다.

== Description ==

Daumbook 플러그인은 isbn으로 "다음검색API"를 이용해 워드프레스에서 책검색 결과를 포스트나 페이지에 쉽게 추가할 수 있도록 도와줍니다. This plugin uses Daum API and helps users easy to use in WordPress.

Tag
[daumbook isbn="129349022"]
[daumbook isbn="129349022" style="width:50%"]

filter
Custom Fields
isbn : 1231234343
or
isbn : 1231234343,1231234343,1231234343...

== Installation ==

1. upload `daumbook.zip` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Place `<?php do_action('plugin_name_hook'); ?>` in your templates

== Screenshots ==

1. `screenshot/customfield.jpg`
2. `screenshot/filter.jpg`
3. `screenshot/shorttag.jpg`

== Changelog ==

== Arbitrary section ==

== A brief Markdown Example ==

`<?php code(); // goes in backticks ?>`